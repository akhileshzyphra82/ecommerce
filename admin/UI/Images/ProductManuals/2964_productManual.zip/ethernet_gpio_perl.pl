﻿#########################################################################################
#   License                                                                             #
#                                                                                       #
#   Copyright © 2018, Numato Systems Private Limited. All rights reserved.              #
#                                                                                       #
#   This software including all supplied files, Intellectual Property, know-how         #
#   Or part of thereof as applicable (collectively called SOFTWARE) in source           #
#   And/Or binary form with accompanying documentation Is licensed to you by            #
#   Numato Systems Private Limited (LICENSOR) subject To the following conditions.      #
#                                                                                       #
#   1. This license permits perpetual use of the SOFTWARE if all conditions in this     #
#       license are met. This license stands revoked In the Event Of breach Of any      #
#       of the conditions.                                                              #
#   2. You may use, modify, copy the SOFTWARE within your organization. This            #
#       SOFTWARE shall Not be transferred To third parties In any form except           #
#       fully compiled binary form As part Of your final application.                   #
#   3. This SOFTWARE Is licensed only to be used in connection with/executed on         #
#       supported products manufactured by Numato Systems Private Limited.              #
#       Using/ executing this SOFTWARE On/In connection With custom Or third party      #
#       hardware without the LICENSORs prior written permission Is expressly            #
#       prohibited.                                                                     #
#   4. You may Not download Or otherwise secure a copy of this SOFTWARE for the         #
#       purpose of competing with Numato Systems Private Limited Or subsidiaries in     #
#       any way such As but Not limited To sharing the SOFTWARE With competitors,       #
#       reverse engineering etc... You may Not Do so even If you have no gain           #
#       financial Or otherwise from such action.                                        #
#   5. DISCLAIMER                                                                       #
#   5.1. USING THIS SOFTWARE Is VOLUNTARY And OPTIONAL. NO PART OF THIS SOFTWARE        #
#       CONSTITUTE A PRODUCT Or PART Of PRODUCT SOLD BY THE LICENSOR.                   #
#   5.2. THIS SOFTWARE And DOCUMENTATION ARE PROVIDED “AS IS” WITH ALL FAULTS,          #
#       DEFECTS And ERRORS And WITHOUT WARRANTY OF ANY KIND.                            #
#   5.3. THE LICENSOR DISCLAIMS ALL WARRANTIES EITHER EXPRESS Or IMPLIED, INCLUDING     #
#       WITHOUT LIMITATION, ANY WARRANTY Of MERCHANTABILITY Or FITNESS For ANY          #
#       PURPOSE.                                                                        #
#   5.4. IN NO EVENT, SHALL THE LICENSOR, IT'S PARTNERS OR DISTRIBUTORS BE LIABLE OR    #
#       OBLIGATED FOR ANY DAMAGES, EXPENSES, COSTS, LOSS Of MONEY, LOSS OF TANGIBLE     #
#       Or INTANGIBLE ASSETS DIRECT Or INDIRECT UNDER ANY LEGAL ARGUMENT SUCH AS BUT    #
#       Not LIMITED TO CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH     #
#       OF WARRANTY Or ANY OTHER SIMILAR LEGAL DEFINITION.                              #
#########################################################################################

#   Perl code demonstrating basic GPIO features Of Numato Lab Ethernet GPIO Module.

#########################################################################################
#                                                                                       #
#                                   Prerequisites                                       #
#                                   -------------                                       #
#                                 install ActivePerl                                    #
#                                   install Switch                                      #
#                                                                                       #
#########################################################################################

#!/usr/bin/perl -w
use diagnostics;
use warnings;
use Net::Telnet;
use Time::HiRes;
use Switch;
my($host, $user, $pass, $command, $result, $gpio_number);
$host = "169.254.1.1";                                      #Device IP Address
$user = "admin";                                            #Device Telnet User Name
$pass = "admin";                                            #Device Telenet Password
    
    
#Create a new TELNET object 
my $telnet = Net::Telnet-> new(Host => $host, Timeout => 1, Port => 23)or die "connect failed: $!";

#Connect to the device using credentials provided   
$telnet->open($host);

$telnet->waitfor('/User Name: *$/i');
$telnet->print($user);

$telnet->waitfor('/Password: *$/i');
$telnet->print($pass);

$result = $telnet->getline(Input_record_separator=>'>');
$result =~ tr/>//d;
print $result;


$gpio_number = "4";                                         #Change the GPIO Number here when required
$adc_number = "3";                                          #Change the ADC Number here when required

if($gpio_number =~ /^[a-v]+(?:,[a-v]+)*?$/) {
$gpio_number = uc $gpio_number;                             #Converts the gpio_number(A to V) to upper case if user entered it as lower case.
}

if($adc_number =~ /^[a-d]+(?:,[a-d]+)*?$/) {
$adc_number = uc $adc_number;                               #Converts the adc_number(A to D) to upper case if user entered it as lower case. 
}

#########################################################################################

#GPIO Set
$command = "gpio set " . $gpio_number . "\n\r"; 
$telnet->print($command);
print "GPIO Set " . $gpio_number;
$telnet->get();
sleep(1);
#########################################################################################

#GPIO Clear
$command = "gpio clear " . $gpio_number . "\n\r"; 
$telnet->print($command);
print "\n\nGPIO Clear " . $gpio_number;
$telnet->get();
sleep(1);
#########################################################################################

#GPIO Read
$command = "gpio read " . $gpio_number . "\n\r";
$telnet->print($command);
sleep(1);
#Read and process response from the device
$result = $telnet->get();
$result =~ tr/\>\n//d;
print "\n\nGPIO read ". $gpio_number . " : " . $result;
#########################################################################################

#ADC Read
$command = "adc read " . $adc_number . "\n\r";
$telnet->print($command);
sleep(1);
#Read and process response from the device
$result = $telnet->get();
$result =~ tr/>//d;
print "\n\nADC read ". $adc_number . " : " . $result;
#########################################################################################
                
#Finally close the Serial Port before exiting
$telnet->close; 