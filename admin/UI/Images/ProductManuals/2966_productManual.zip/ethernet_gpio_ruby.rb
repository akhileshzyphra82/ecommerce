#########################################################################################
#   License                                                                             #
#                                                                                       #
#   Copyright © 2018, Numato Systems Private Limited. All rights reserved.              #
#                                                                                       #
#   This software including all supplied files, Intellectual Property, know-how         #
#   Or part of thereof as applicable (collectively called SOFTWARE) in source           #
#   And/Or binary form with accompanying documentation Is licensed to you by            #
#   Numato Systems Private Limited (LICENSOR) subject To the following conditions.      #
#                                                                                       #
#   1. This license permits perpetual use of the SOFTWARE if all conditions in this     #
#       license are met. This license stands revoked In the Event Of breach Of any      #
#       of the conditions.                                                              #
#   2. You may use, modify, copy the SOFTWARE within your organization. This            #
#       SOFTWARE shall Not be transferred To third parties In any form except           #
#       fully compiled binary form As part Of your final application.                   #
#   3. This SOFTWARE Is licensed only to be used in connection with/executed on         #
#       supported products manufactured by Numato Systems Private Limited.              #
#       Using/ executing this SOFTWARE On/In connection With custom Or third party      #
#       hardware without the LICENSORs prior written permission Is expressly            #
#       prohibited.                                                                     #
#   4. You may Not download Or otherwise secure a copy of this SOFTWARE for the         #
#       purpose of competing with Numato Systems Private Limited Or subsidiaries in     #
#       any way such As but Not limited To sharing the SOFTWARE With competitors,       #
#       reverse engineering etc... You may Not Do so even If you have no gain           #
#       financial Or otherwise from such action.                                        #
#   5. DISCLAIMER                                                                       #
#   5.1. USING THIS SOFTWARE Is VOLUNTARY And OPTIONAL. NO PART OF THIS SOFTWARE        #
#       CONSTITUTE A PRODUCT Or PART Of PRODUCT SOLD BY THE LICENSOR.                   #
#   5.2. THIS SOFTWARE And DOCUMENTATION ARE PROVIDED “AS IS” WITH ALL FAULTS,          #
#       DEFECTS And ERRORS And WITHOUT WARRANTY OF ANY KIND.                            #
#   5.3. THE LICENSOR DISCLAIMS ALL WARRANTIES EITHER EXPRESS Or IMPLIED, INCLUDING     #
#       WITHOUT LIMITATION, ANY WARRANTY Of MERCHANTABILITY Or FITNESS For ANY          #
#       PURPOSE.                                                                        #
#   5.4. IN NO EVENT, SHALL THE LICENSOR, IT'S PARTNERS OR DISTRIBUTORS BE LIABLE OR    #
#       OBLIGATED FOR ANY DAMAGES, EXPENSES, COSTS, LOSS Of MONEY, LOSS OF TANGIBLE     #
#       Or INTANGIBLE ASSETS DIRECT Or INDIRECT UNDER ANY LEGAL ARGUMENT SUCH AS BUT    #
#       Not LIMITED TO CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH     #
#       OF WARRANTY Or ANY OTHER SIMILAR LEGAL DEFINITION.                              #
#########################################################################################

#   Ruby code demonstrating basic GPIO features Of Numato Lab Ethernet GPIO Module.

#########################################################################################
#                                                                                       #
#                                   Prerequisites                                       #
#                                   -------------                                       #
#                                 install Ruby Installer                                #
#                                                                                       #
#########################################################################################
require 'net/telnet'

$host = "169.254.1.1"                                       #Device IP Address
$user = "admin"                                             #Device Telnet User Name
$pass = "admin"                                             #Device Telnet Password

#Connect to device with user provided credentials
def connect
    #Create a new TELNET object
    $telnet_obj = Net::Telnet::new("Host" => $host,
                                 "Port" => 23,
                                 "Timeout" => 10,
                                 "Prompt" => /User Name: /,
                                 "Output_log"=>"output_log.log", 
                                 "Dump_log"=>"dump_log.log")

    $telnet_obj.cmd("String" => $user)                           
    $login =  $telnet_obj.cmd("String" => "   " + $pass, "Match" => />/)  { |c| print c.tr('>', '') }
    puts "----------------------"
end

connect()
gpio_number = "7"                                           #Change the GPIO Number here when required
adc_number = "5"                                            #Change the ADC Number here when required

if gpio_number.match(/^[a-v]*$/)
    gpio_number = gpio_number.upcase                        #Converts the gpio_number(A to V) to upper case if user entered it as lower case.
end

if adc_number.match(/^[a-d]*$/)
    adc_number = adc_number.upcase                          #Converts the adc_number(A to D) to upper case if user entered it as lower case. 
end

#########################################################################################

#GPIO Set
$telnet_obj.cmd("String" => "gpio set " + gpio_number, "Match" => />/) { |c| print c.tr('>', '') }
puts "\nGPIO Set " + gpio_number
sleep(1)    
#########################################################################################

#GPIO Clear
$telnet_obj.cmd("String" => "gpio clear " + gpio_number, "Match" => />/) { |c| print c.tr('>', '') }
puts "\nGPIO Clear " + gpio_number
sleep(1)
#########################################################################################

#GPIO Read
print "\nGPIO read ", gpio_number, " : "
$telnet_obj.cmd("String" => "gpio read " + gpio_number, "Match" => />/) { |c| print c.tr('>', '') }
sleep(1)
#########################################################################################

#ADC Read
print "\nADC read " adc_number, " : "
$telnet_obj.cmd("String" => "adc read " + adc_number, "Match" => />/) { |c| print c.tr('>', '') }
sleep(1)
#########################################################################################

#Finally close the TELNET session before exiting
$telnet_obj.close


