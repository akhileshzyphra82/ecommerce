set_property -dict { PACKAGE_PIN "F22"    IOSTANDARD LVCMOS33       SLEW FAST} [get_ports { sys_clock }]     ;                       
set_property -dict { PACKAGE_PIN "C26"    IOSTANDARD LVCMOS33      PULLDOWN True} [get_ports { reset }]    ;  

#UART
set_property -dict { PACKAGE_PIN "K22"    IOSTANDARD LVCMOS33   SLEW FAST} [get_ports { uart_rxd }]    ;                       
set_property -dict { PACKAGE_PIN "H22"    IOSTANDARD LVCMOS33   SLEW FAST} [get_ports { uart_txd }]    ;            

# ADC_0
set_property -dict { PACKAGE_PIN "C18"    IOSTANDARD LVCMOS33       SLEW FAST} [get_ports { adc_reset_0 }]   ;  
set_property -dict { PACKAGE_PIN "L17"    IOSTANDARD LVCMOS33       SLEW FAST} [get_ports { spi_0_sck_io }]   ;
set_property -dict { PACKAGE_PIN "G20"    IOSTANDARD LVCMOS33       SLEW FAST} [get_ports { convst_0 }]   ;
set_property -dict { PACKAGE_PIN "H19"    IOSTANDARD LVCMOS33       SLEW FAST} [get_ports { spi_0_ss_io }]   ;
set_property -dict { PACKAGE_PIN "K18"    IOSTANDARD LVCMOS33       SLEW FAST} [get_ports { busy_0 }]   ;
set_property -dict { PACKAGE_PIN "F18"    IOSTANDARD LVCMOS33       SLEW FAST} [get_ports { spi_0_io1_io }]   ;
set_property -dict { PACKAGE_PIN "G17"    IOSTANDARD LVCMOS33       SLEW FAST} [get_ports { spi_0_io0_io }]   ;

# ADC_1        
set_property -dict { PACKAGE_PIN "Y25"    IOSTANDARD LVCMOS33       SLEW FAST} [get_ports { adc_reset_1 }]   ; 
set_property -dict { PACKAGE_PIN "H16"    IOSTANDARD LVCMOS33       SLEW FAST} [get_ports { spi_1_sck_io }]   ;                       
set_property -dict { PACKAGE_PIN "D18"    IOSTANDARD LVCMOS33       SLEW FAST} [get_ports { convst_1 }]   ;                      
set_property -dict { PACKAGE_PIN "K17"    IOSTANDARD LVCMOS33       SLEW FAST} [get_ports { spi_1_ss_io }]   ;                     
set_property -dict { PACKAGE_PIN "K16"    IOSTANDARD LVCMOS33       SLEW FAST} [get_ports { busy_1 }]   ;                       
set_property -dict { PACKAGE_PIN "M17"    IOSTANDARD LVCMOS33       SLEW FAST} [get_ports { spi_1_io1_io }]   ;                     
set_property -dict { PACKAGE_PIN "W20"    IOSTANDARD LVCMOS33       SLEW FAST} [get_ports { spi_1_io0_io }]   ;                              


