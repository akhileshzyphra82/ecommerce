`timescale 1ns / 1ps

module falling_edge_detector(
    clk, busy, falling_edge
);

input clk;
input busy;
output falling_edge;

reg busy_a;
reg busy_b;
reg old_busy;
  
always@(posedge clk) begin
    busy_a <= busy;
    busy_b <= busy_a;
    old_busy <= busy_b;
end

assign falling_edge = !busy & old_busy; 
       
endmodule
