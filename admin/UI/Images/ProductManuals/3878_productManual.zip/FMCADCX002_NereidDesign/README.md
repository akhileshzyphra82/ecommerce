FMCADCX002 Nereid Sample Project
Numato Lab
https://www.numato.com

This package contains source and other files necessary to build this project for Nereid Kintex 7 PCI Express FPGA Development board.

This project is created by selecting the part number of Nereid Development board instead of selecting the board itself.

Quickstart: Connect FMCADCX002 module with FMCADCX002 breakout board to the FMC connector of Nereid. Connect USB Micro cable and JTAG and power up Nereid. Give input(s) from analog source to any channel(s) of FMCADCX002 module.
Conversions at corresponding channels of an ADC (A0 and B0, A1 and B1, and so on for ADC 1; C0 and D0, C1 and D1, and so on for ADC 0) occur simultaneously.

Open the COM port corresponding to Nereid in any serial terminal application (PuTTy, Tera Term etc). Open Vivado Hardware Manager and program Nereid with "FMCADCX002_NereidDesign.bit" in "Bitstreams" folder. Observe the output displayed in the serial terminal. 
Select the ADC, input range and channel for conversion as required. 
You can observe the analog readings corresponding to the analog input(s) at the selected channel pair.

You can press `Q` while reading the output of a channel pair, to quit testing that channel pair and start the test from the beginning. 
Also, you can quit the test anytime by pressing `Q`. If you press `RESET` switch on Nereid at anytime during the tests, the program will execute from the beginning.

Using the project: Open the project(.xpr) file and Open the Block Design. Then Generate the Bitstream along with binary file
(select it in Generate Bitstream settings). After the Bitstream is generated successfully, the .bit and .bin
files will be created in the "FMCADCX002_NereidDesign.runs-->impl_1" folder.

Launch Xilinx SDK. Connect the hardware as described in *Quickstart* and open the COM port corresponding to Nereid in any serial terminal application.
Program the FPGA on Nereid with a simple bootloop program by selecting “Program FPGA” option from “Xilinx” menu.
Now, right click on the .elf file in the Project Explorer and select “Launch on Hardware” (NOTE: ELF file needs to be 
downloaded to Nereid via JTAG after programming .bit file).
You can observe the output as described in *Quickstart* in the serial terminal.


