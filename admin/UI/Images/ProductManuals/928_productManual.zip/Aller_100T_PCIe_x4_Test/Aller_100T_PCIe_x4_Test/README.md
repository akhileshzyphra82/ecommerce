Aller 100T PCIe x4 Project
Numato Lab
https://www.numato.com

This package contains source and other files necessary to build this project for Aller FPGA Development board.

This project is created by selecting the part number of Aller board instead of selecting the board itself.

Open the project(.xpr) file and first synthesize. If Synthesis is successfull, then Run Implementation. 
After Implementation is completed successfully, Generate the Bitstream. After the Bitstream is generated 
successfully, the .bit and .bin files will be created in the "Aller_100T_PCIe_x4_Test.runs-->impl_1" folder.
Open Hardware Manager under Flow Navigator and Add Memory Configuration File by selecting the Part Number and
select the .bin file and program the board. After programming the board, test it on Linux system.