FMCADCX002 Proteus Sample Project
Numato Lab
https://www.numato.com

This package contains source and other files necessary to build this project for Proteus Kintex 7 USB 3.1 Development board.

This project is created by selecting the part number of Proteus Development board instead of selecting the board itself.

This design uses JTAG UART instead of USB UART and to use this project JTAG is required.

Quickstart: Connect FMCADCX002 module with FMCADCX002 breakout board to the FMC connector of Proteus. Connect JTAG and power up the FPGA board. Connect input(s) from analog source to any channel(s) of the module.
Conversions at corresponding channels of an ADC (A0 and B0, A1 and B1, and so on for ADC 1; C0 and D0, C1 and D1, and so on for ADC 0) occur simultaneously.

In the "Bitstreams" folder, edit the batch file "download.bat" to specify the correct location of "xsct.bat" in your Vivado.
Now, double-click "download.bat" file. Observe the output displayed in the PuTTY window that pops up. 
Select the ADC, input range and channel for conversion as required. 
You can observe the analog readings corresponding to the analog input(s) at the selected channel pair.

You can press `Q` while reading the output of a channel pair, to quit testing that channel pair and start the test from the beginning. 
Also, you can quit the test anytime by pressing `Q`. If you press Reset switch on Proteus at anytime during the tests, the program will execute from the beginning.

Using the project: Open the project(.xpr) file and Open the Block Design. Then Generate the Bitstream. After the Bitstream is generated successfully, the .bit 
file will be created in the "FMCADCX002_ProteusDesign.runs-->impl_1" folder.

Connect FMCADCX002 module and provide analog input(s) as described in Quickstart.
In Xilinx SDK, program the FPGA on Proteus with a simple bootloop program by selecting “Program FPGA” option from “Xilinx” menu.
Now, right click on the .elf file in the Project Explorer and select “Launch on Hardware”(NOTE: ELF file needs to be 
downloaded to Proteus via JTAG after programming .bit file).
You can observe the output as described in Quickstart in the SDK console.


