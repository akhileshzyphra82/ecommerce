connect
fpga FMCADCX002_ProteusDesign.bit
targets 3
set port [jtagterminal -socket]
puts "JTAG Terminal Started on Port $port"
exec putty -raw -load JTAGTerminal localhost $port &
dow FMCADCX002_ProteusDesign.elf
con


