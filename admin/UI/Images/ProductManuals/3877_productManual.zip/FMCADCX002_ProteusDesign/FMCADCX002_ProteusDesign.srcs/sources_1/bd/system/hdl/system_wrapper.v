//Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2018.2 (win64) Build 2258646 Thu Jun 14 20:03:12 MDT 2018
//Date        : Tue Jan 21 16:46:38 2020
//Host        : DESKTOP-DPQAEVA running 64-bit major release  (build 9200)
//Command     : generate_target system_wrapper.bd
//Design      : system_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module system_wrapper
   (adc_reset_0,
    adc_reset_1,
    busy_0,
    busy_1,
    convst_0,
    convst_1,
    reset,
    spi_0_io0_io,
    spi_0_io1_io,
    spi_0_sck_io,
    spi_0_ss_io,
    spi_1_io0_io,
    spi_1_io1_io,
    spi_1_sck_io,
    spi_1_ss_io,
    sys_clock);
  output [0:0]adc_reset_0;
  output [0:0]adc_reset_1;
  input busy_0;
  input busy_1;
  output [0:0]convst_0;
  output [0:0]convst_1;
  input reset;
  inout spi_0_io0_io;
  inout spi_0_io1_io;
  inout spi_0_sck_io;
  inout [0:0]spi_0_ss_io;
  inout spi_1_io0_io;
  inout spi_1_io1_io;
  inout spi_1_sck_io;
  inout [0:0]spi_1_ss_io;
  input sys_clock;

  wire [0:0]adc_reset_0;
  wire [0:0]adc_reset_1;
  wire busy_0;
  wire busy_1;
  wire [0:0]convst_0;
  wire [0:0]convst_1;
  wire reset;
  wire spi_0_io0_i;
  wire spi_0_io0_io;
  wire spi_0_io0_o;
  wire spi_0_io0_t;
  wire spi_0_io1_i;
  wire spi_0_io1_io;
  wire spi_0_io1_o;
  wire spi_0_io1_t;
  wire spi_0_sck_i;
  wire spi_0_sck_io;
  wire spi_0_sck_o;
  wire spi_0_sck_t;
  wire [0:0]spi_0_ss_i_0;
  wire [0:0]spi_0_ss_io_0;
  wire [0:0]spi_0_ss_o_0;
  wire spi_0_ss_t;
  wire spi_1_io0_i;
  wire spi_1_io0_io;
  wire spi_1_io0_o;
  wire spi_1_io0_t;
  wire spi_1_io1_i;
  wire spi_1_io1_io;
  wire spi_1_io1_o;
  wire spi_1_io1_t;
  wire spi_1_sck_i;
  wire spi_1_sck_io;
  wire spi_1_sck_o;
  wire spi_1_sck_t;
  wire [0:0]spi_1_ss_i_0;
  wire [0:0]spi_1_ss_io_0;
  wire [0:0]spi_1_ss_o_0;
  wire spi_1_ss_t;
  wire sys_clock;

  IOBUF spi_0_io0_iobuf
       (.I(spi_0_io0_o),
        .IO(spi_0_io0_io),
        .O(spi_0_io0_i),
        .T(spi_0_io0_t));
  IOBUF spi_0_io1_iobuf
       (.I(spi_0_io1_o),
        .IO(spi_0_io1_io),
        .O(spi_0_io1_i),
        .T(spi_0_io1_t));
  IOBUF spi_0_sck_iobuf
       (.I(spi_0_sck_o),
        .IO(spi_0_sck_io),
        .O(spi_0_sck_i),
        .T(spi_0_sck_t));
  IOBUF spi_0_ss_iobuf_0
       (.I(spi_0_ss_o_0),
        .IO(spi_0_ss_io[0]),
        .O(spi_0_ss_i_0),
        .T(spi_0_ss_t));
  IOBUF spi_1_io0_iobuf
       (.I(spi_1_io0_o),
        .IO(spi_1_io0_io),
        .O(spi_1_io0_i),
        .T(spi_1_io0_t));
  IOBUF spi_1_io1_iobuf
       (.I(spi_1_io1_o),
        .IO(spi_1_io1_io),
        .O(spi_1_io1_i),
        .T(spi_1_io1_t));
  IOBUF spi_1_sck_iobuf
       (.I(spi_1_sck_o),
        .IO(spi_1_sck_io),
        .O(spi_1_sck_i),
        .T(spi_1_sck_t));
  IOBUF spi_1_ss_iobuf_0
       (.I(spi_1_ss_o_0),
        .IO(spi_1_ss_io[0]),
        .O(spi_1_ss_i_0),
        .T(spi_1_ss_t));
  system system_i
       (.adc_reset_0(adc_reset_0),
        .adc_reset_1(adc_reset_1),
        .busy_0(busy_0),
        .busy_1(busy_1),
        .convst_0(convst_0),
        .convst_1(convst_1),
        .reset(reset),
        .spi_0_io0_i(spi_0_io0_i),
        .spi_0_io0_o(spi_0_io0_o),
        .spi_0_io0_t(spi_0_io0_t),
        .spi_0_io1_i(spi_0_io1_i),
        .spi_0_io1_o(spi_0_io1_o),
        .spi_0_io1_t(spi_0_io1_t),
        .spi_0_sck_i(spi_0_sck_i),
        .spi_0_sck_o(spi_0_sck_o),
        .spi_0_sck_t(spi_0_sck_t),
        .spi_0_ss_i(spi_0_ss_i_0),
        .spi_0_ss_o(spi_0_ss_o_0),
        .spi_0_ss_t(spi_0_ss_t),
        .spi_1_io0_i(spi_1_io0_i),
        .spi_1_io0_o(spi_1_io0_o),
        .spi_1_io0_t(spi_1_io0_t),
        .spi_1_io1_i(spi_1_io1_i),
        .spi_1_io1_o(spi_1_io1_o),
        .spi_1_io1_t(spi_1_io1_t),
        .spi_1_sck_i(spi_1_sck_i),
        .spi_1_sck_o(spi_1_sck_o),
        .spi_1_sck_t(spi_1_sck_t),
        .spi_1_ss_i(spi_1_ss_i_0),
        .spi_1_ss_o(spi_1_ss_o_0),
        .spi_1_ss_t(spi_1_ss_t),
        .sys_clock(sys_clock));
endmodule
