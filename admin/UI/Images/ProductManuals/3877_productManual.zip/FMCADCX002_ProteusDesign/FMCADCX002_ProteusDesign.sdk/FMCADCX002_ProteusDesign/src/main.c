/***************************** Include Files *********************************/
#include "xparameters.h"    /* XPAR parameters */
#include "xspi.h"
#include "xgpio.h"
#include "xuartlite_l.h"
/************************** Constant Definitions *****************************/
#define DUMMY               0x00000000  
#define ADC_0               2
#define ADC_1               1
/************************** Function Prototypes ******************************/
s32 adc_reg_write(u32);
s32 adc_reg_read(u32);
void spi_write_data(u32);
s32 spi_read_data();
void adc_reset(int);
void delay(u32);
int TwosComplementToDec(s16);
int SysMonFractionToInt(float);
/************************** Variable Definitions *****************************/
/*
 * The instances to support the device drivers are global such that they
 * are initialized to zero each time the program runs.
 */
XSpi Spi;
XGpio Gpio;
XGpio ResetGpio;

int main(void) {
    XSpi_Config *Spi_cfgPtr;
    XGpio_Config *Gpio_cfgPtr;
    XGpio_Config *Reset_cfgPtr;
    u32 channel_reg;    /* Configure channel register */
    u32 config_reg = 0x00008400;    /* Configure configuration register */
    u32 input_range_a1; /* Configure Input Range A1 register */
    u32 input_range_a2; /* Configure Input Range A2 register */
    u32 input_range_b1; /* Configure Input Range B1 register */
    u32 input_range_b2; /* Configure Input Range B2 register */

    u16 SPI_DEVICE_ID;
    u16 GPIO_DEVICE_ID;
    u8 adc = 0;
    u8 input_range = 0;
    u8 channel = 0;
    u8 invalid_channel = 0;
    u8 invalid_range = 0;
    u8 invalid_adc = 0;
    u8 repeat = 0;
    float range;
    char channel_1;
    char channel_2;

    /* Lookup Reset GPIO peripheral configuration details */
    Reset_cfgPtr = XGpio_LookupConfig(XPAR_GPIO_2_DEVICE_ID);
    if (Reset_cfgPtr == NULL)   
        return 2;   

    if(XGpio_CfgInitialize(&ResetGpio, Reset_cfgPtr, Reset_cfgPtr->BaseAddress) != XST_SUCCESS)    
        return 1;
    
    /* Configure both channels of ResetGpio as Output */
    XGpio_SetDataDirection(&ResetGpio, 1, 0);
    XGpio_SetDataDirection(&ResetGpio, 2, 0);

    /* Full reset of ADC_0 after power up */
    adc_reset(ADC_0);

    /* Full reset of ADC_1 after power up */
    adc_reset(ADC_1);

    print("\r\n\r\n\e[1;36mFMCADCX002 Proteus Design Suite\e[0m\r\n");
    print("\e[1;36m______________________________\e[0m\r\n\r\n");
    print("\r\nWelcome to FMCADCX002 Proteus Design Suite\r\n\n");

    do{

        /* Flush UART incoming FIFO */
        while (XUartLite_IsReceiveEmpty(STDIN_BASEADDRESS) != 1) {
            ch = inbyte();
        }

        print("\r\nPlease choose the ADC for conversion, [Q] to Quit:\r\n\n");
        print("\t0. ADC 0\r\n");
        print("\t1. ADC 1\r\n");
        print(">> ");
        repeat = 1;

        do{
            while (XUartLite_IsReceiveEmpty(STDIN_BASEADDRESS));
  
            adc = inbyte();
            adc = toupper(adc);
            invalid_adc = 0;
            xil_printf("%c\r\n", adc);

            switch (adc) {
                case '0': SPI_DEVICE_ID = XPAR_SPI_0_DEVICE_ID;
                          GPIO_DEVICE_ID = XPAR_GPIO_0_DEVICE_ID;
                          channel_1 = 'C';
                          channel_2 = 'D'; break;
                case '1': SPI_DEVICE_ID = XPAR_SPI_1_DEVICE_ID;
                          GPIO_DEVICE_ID = XPAR_GPIO_1_DEVICE_ID;
                          channel_1 = 'A';
                          channel_2 = 'B'; break;
                case 'Q': repeat = 0; break;
                default: invalid_adc = 1; break;
            }
        } while(invalid_adc);

        if(repeat == 0) break;

        print("\r\nPlease choose the required Input Range, [Q] to Quit:\r\n\n");
        print("\t1. +/- 10V\r\n");
        print("\t2. +/- 5V\r\n");
        print("\t3. +/- 2.5V\r\n");
        print(">> ");

        do{
            while (XUartLite_IsReceiveEmpty(STDIN_BASEADDRESS));

            input_range = inbyte();
            input_range = toupper(input_range);
            invalid_range = 0;
            xil_printf("%c\r\n", input_range);

            switch (input_range) {
                case '1': input_range_a1 = 0x000088FF;
                          input_range_a2 = 0x00008AFF;
                          input_range_b1 = 0x00008CFF;
                          input_range_b2 = 0x00008EFF;
                          range = 10; break;
                case '2': input_range_a1 = 0x000088AA;
                          input_range_a2 = 0x00008AAA;
                          input_range_b1 = 0x00008CAA;
                          input_range_b2 = 0x00008EAA;
                          range = 5; break;
                case '3': input_range_a1 = 0x00008855;
                          input_range_a2 = 0x00008A55;
                          input_range_b1 = 0x00008C55;
                          input_range_b2 = 0x00008E55;
                          range = 2.5; break;
                case 'Q': repeat = 0; break;
                default: invalid_range = 1; break;
            }
        } while(invalid_range);

        if(repeat == 0) break;

        print("\r\nPlease choose the Channel for conversion, [Q] to Quit:\r\n\n");
        print("\t0. Channel 0\r\n");
        print("\t1. Channel 1\r\n");
        print("\t2. Channel 2\r\n");
        print("\t3. Channel 3\r\n");
        print("\t4. Channel 4\r\n");
        print("\t5. Channel 5\r\n");
        print("\t6. Channel 6\r\n");
        print("\t7. Channel 7\r\n");
        print(">> ");

        do{

            while (XUartLite_IsReceiveEmpty(STDIN_BASEADDRESS));

            channel = inbyte();
            channel = toupper(channel);
            invalid_channel = 0;
            xil_printf("%c\r\n", channel);

            switch (channel) {
                case '0': channel_reg = 0x00008600; break;
                case '1': channel_reg = 0x00008611; break;
                case '2': channel_reg = 0x00008622; break;
                case '3': channel_reg = 0x00008633; break;
                case '4': channel_reg = 0x00008644; break;
                case '5': channel_reg = 0x00008655; break;
                case '6': channel_reg = 0x00008666; break;
                case '7': channel_reg = 0x00008677; break;
                case 'Q': repeat = 0; break;
                default: invalid_channel = 1; break;
            }
        } while(invalid_channel);

        if(repeat == 0) break;

        /* Lookup CONVST GPIO configuration details */
        Gpio_cfgPtr = XGpio_LookupConfig(GPIO_DEVICE_ID);
        if (Gpio_cfgPtr == NULL)
            return 2;
     
        if(XGpio_CfgInitialize(&Gpio, Gpio_cfgPtr, Gpio_cfgPtr->BaseAddress) != XST_SUCCESS)
            return 1;

        /* Configure channel 1 of Gpio as Output for CONVST */
        XGpio_SetDataDirection(&Gpio, 1, 0);

        /* Configure channel 2 of Gpio as Input for busy falling edge */
        XGpio_SetDataDirection(&Gpio, 2, 1);

        /* Enable global interrupt */
        XGpio_InterruptGlobalEnable(&Gpio);

        /* Enable channel 2 interrupt */
        XGpio_InterruptEnable(&Gpio, XGPIO_IR_CH2_MASK);

        /* Lookup SPI peripheral configuration details */
        Spi_cfgPtr = XSpi_LookupConfig(SPI_DEVICE_ID);

        if (Spi_cfgPtr == NULL)        
            return 2;        

        if(XSpi_CfgInitialize(&Spi, Spi_cfgPtr, Spi_cfgPtr->BaseAddress) != XST_SUCCESS)
            return 1;
        
        /* Set up SPI controller. */
        XSpi_SetControlReg(&Spi, 0x8E);

        /* Configure on-chip registers */
        adc_reg_write(config_reg);
        adc_reg_write(channel_reg);
        adc_reg_write(input_range_a1);
        adc_reg_write(input_range_a2);
        adc_reg_write(input_range_b1);
        adc_reg_write(input_range_b2);

        u8 loop = 0;
        u8 exit = 0;

        /* Flush UART incoming FIFO */
        while (XUartLite_IsReceiveEmpty(STDIN_BASEADDRESS) != 1) {
            exit = inbyte();
        }

        do {

            if (XUartLite_IsReceiveEmpty(STDIN_BASEADDRESS)) {
                loop = 1;
            } else {
                exit = inbyte();
                exit = toupper(exit);
                loop = 1;
                if (exit == 'Q') {
                    loop = 0;
                }
            }

            if (loop){

                /* Generate CONVST */
                XGpio_DiscreteWrite(&Gpio, 1, 1);
                XGpio_DiscreteWrite(&Gpio, 1, 0);

                /* Read conversion results after busy falling edge */
                if(XGpio_InterruptGetStatus(&Gpio) == 2)
                {
                    /* 32 SCLK cycles are required to read data from both the channels in serial 1-wire mode */
                    s32 ChannelData = adc_reg_write(DUMMY);  /* Read data from channels A & B */
                    
                    s16 DataA = (ChannelData >> 16) & 0x0000FFFF;
                    s16 DataB = ChannelData & 0x0000FFFF;

                    /* Calculate the decimal value corresponding to the 2's complement output code of the ADC. */
                    int decimalA = TwosComplementToDec(DataA);
                    int decimalB = TwosComplementToDec(DataB);

                    /* Calculate the analog value based on the ADC transfer function. */
                    float analogA = ((float)decimalA*range)/32768 ;
                    float analogB = ((float)decimalB*range)/32768 ;

                    if(((DataA & 0x8000) != 0) && (int)analogA == 0 )
                        xil_printf("\rChannel %c = -%02d.%03dV        ", channel_1, (int)analogA, SysMonFractionToInt(analogA));
                    else
                        xil_printf("\rChannel %c = %02d.%03dV        ", channel_1, (int)analogA, SysMonFractionToInt(analogA));

                    if(((DataB & 0x8000) != 0) && (int)analogB == 0 )
                        xil_printf("Channel %c = -%02d.%03dV        ", channel_2, (int)analogB, SysMonFractionToInt(analogB));
                    else
                        xil_printf("Channel %c = %02d.%03dV        ", channel_2, (int)analogB, SysMonFractionToInt(analogB));

                    XGpio_InterruptClear(&Gpio, XGPIO_IR_CH2_MASK);
                }
                delay(5000000);
            }
        } while (loop);
        xil_printf("\n\r");
    } while (repeat);

    print("\r\n\r\nThank You.\r\n\n");
    return 0;
}

/* This function writes to AD7616 register, and returns the bytes it receives while performing the write. */
s32 adc_reg_write(u32 WriteData)
{
    XSpi_SetSlaveSelectReg(&Spi, 0x00);
    spi_write_data(WriteData);
    s32 ReadData = spi_read_data();
    XSpi_SetSlaveSelectReg(&Spi, 0x01);

    return ReadData;
}

/* This function reads data from AD7616 register */
s32 adc_reg_read(u32 command)
{
    s32 DataRead;
    adc_reg_write(command);
    DataRead = adc_reg_write(DUMMY);
    s32 RegData = DataRead & 0xFFFF0000;

    return RegData;
}

/* This function writes four bytes to the SPI peripheral */
void spi_write_data(u32 data)
{
    while(XSpi_GetStatusReg(&Spi) & 0x08);
    XSpi_WriteReg(Spi.BaseAddr, XSP_DTR_OFFSET, data);
}

/* This function reads four bytes from the SPI peripheral */
s32 spi_read_data()
{
    while(!(XSpi_ReadReg(Spi.BaseAddr, XSP_SR_OFFSET) & 0x02));
    return XSpi_ReadReg(Spi.BaseAddr, XSP_DRR_OFFSET);
}

/* This function resets the ADC */
void adc_reset(int gpio_channel){
    XGpio_DiscreteWrite(&ResetGpio, gpio_channel, 0);
    delay(10);
    XGpio_DiscreteWrite(&ResetGpio, gpio_channel, 1);
}

/* This fuction returns the decimal value corresponding to its 2's complement argument */
int TwosComplementToDec(s16 data){
    int decimal;
    s16 value;

    if((data & 0x8000) != 0){
        value = ~(data - 0x0001);
        if((value & 0x8000) != 0)
            decimal = (int)value;
        else
            decimal = (int)value * -1;
    }
    else{
        decimal = (int)data;
    }
    return decimal;
}

/* Function to convert fraction part of float into an integer from 
 * https://github.com/Xilinx/embeddedsw/blob/master/XilinxProcessorIPLib/drivers/sysmon/examples/xsysmon_intr_printf_example.c */
int SysMonFractionToInt(float FloatNum)
{
    float Temp;
    Temp = FloatNum;

    if (FloatNum < 0) {
        Temp = -(FloatNum);
    }

    return( ((int)((Temp -(float)((int)Temp)) * (1000.0f))));
}

void delay(u32 n){
    for (u32 i = 0; i < n; i++);
}