/*

   License                                                                             
                                                                                       
   Copyright © 2018, Numato Systems Private Limited. All rights reserved.              
                                                                                       
   This software including all supplied files, Intellectual Property, know-how         
   Or part of thereof as applicable (collectively called SOFTWARE) in source           
   And/Or binary form with accompanying documentation Is licensed to you by            
   Numato Systems Private Limited (LICENSOR) subject To the following conditions.      
                                                                                       
   1. This license permits perpetual use of the SOFTWARE if all conditions in this     
       license are met. This license stands revoked In the Event Of breach Of any      
       of the conditions.                                                              
   2. You may use, modify, copy the SOFTWARE within your organization. This            
       SOFTWARE shall Not be transferred To third parties In any form except           
       fully compiled binary form As part Of your final application.                   
   3. This SOFTWARE Is licensed only to be used in connection with/executed on         
       supported products manufactured by Numato Systems Private Limited.              
       Using/ executing this SOFTWARE On/In connection With custom Or third party      
       hardware without the LICENSORs prior written permission Is expressly            
       prohibited.                                                                     
   4. You may Not download Or otherwise secure a copy of this SOFTWARE for the         
       purpose of competing with Numato Systems Private Limited Or subsidiaries in     
       any way such As but Not limited To sharing the SOFTWARE With competitors,       
       reverse engineering etc... You may Not Do so even If you have no gain           
       financial Or otherwise from such action.                                        
   5. DISCLAIMER                                                                       
   5.1. USING THIS SOFTWARE Is VOLUNTARY And OPTIONAL. NO PART OF THIS SOFTWARE        
       CONSTITUTE A PRODUCT Or PART Of PRODUCT SOLD BY THE LICENSOR.                   
   5.2. THIS SOFTWARE And DOCUMENTATION ARE PROVIDED “AS IS” WITH ALL FAULTS,          
       DEFECTS And ERRORS And WITHOUT WARRANTY OF ANY KIND.                            
   5.3. THE LICENSOR DISCLAIMS ALL WARRANTIES EITHER EXPRESS Or IMPLIED, INCLUDING     
       WITHOUT LIMITATION, ANY WARRANTY Of MERCHANTABILITY Or FITNESS For ANY          
       PURPOSE.                                                                        
   5.4. IN NO EVENT, SHALL THE LICENSOR, IT'S PARTNERS OR DISTRIBUTORS BE LIABLE OR    
       OBLIGATED FOR ANY DAMAGES, EXPENSES, COSTS, LOSS Of MONEY, LOSS OF TANGIBLE     
       Or INTANGIBLE ASSETS DIRECT Or INDIRECT UNDER ANY LEGAL ARGUMENT SUCH AS BUT    
       Not LIMITED TO CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH     
       OF WARRANTY Or ANY OTHER SIMILAR LEGAL DEFINITION.  

    Perl code demonstrating basic GPIO features Of Numato Lab Ethernet GPIO Module.

    Prerequisites                                       
    -------------  
   install JDK
   install Netbeans 
*/

package ethernetgpiodemo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.net.telnet.TelnetClient;

/**
 *
 * @author Numato Lab
 */
public class EthernetGpioDemo {

    /**
     * @param args the command line arguments
     */
    static OutputStream outstr;
    static InputStream intstr;
    static TelnetClient tc;

    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        
        tc = new TelnetClient(); //new TELNET object
        String ipAddress = "169.254.1.1"; //IP Address
        int port = 23; //Telnet Port Number
        String gpioNumber = "3"; //Change the GPIO Number here when required
        String adcNumber = "3"; //Change the ADC Number here when required
        try {
            //Telnet Connection
            tc.connect(ipAddress, port);
            outstr = tc.getOutputStream();
            intstr = tc.getInputStream();
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            if (tc != null) {
                // Buffer to store the response bytes.
                byte[] data = new byte[256];
                // Read the first batch of the TcpServer response bytes.
                int bytes = intstr.read(data, 0, data.length);
                String responseData = new String(data, 0, bytes);
                String result = responseData;
                if (responseData.contains("User Name: ")) {
                    String message = "admin"; //Device telnet user name
                    // Translate the passed message into ASCII and store it as a Byte array.
                    data = (new String(message + "\r\n")).getBytes("UTF-8");
                    // Send the message to the connected TcpServer. 
                    outstr.write(data, 0, data.length);
                    outstr.flush();
                }
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                data = new byte[256];

                // Read the first batch of the TcpServer response bytes.
                bytes = intstr.read(data, 0, data.length);
                responseData = new String(data, 0, bytes);
                result = result + responseData;
                if (responseData.contains("Password: ")) {
                    String message = "admin"; //Device telnet password
                    // Translate the passed message into ASCII and store it as a Byte array.
                    data = (new String(message + "\r\n")).getBytes("UTF-8");
                    // Send the message to the connected TcpServer. 
                    outstr.write(data, 0, data.length);
                    outstr.flush();
                }
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                data = new byte[256];
                bytes = intstr.read(data, 0, data.length);
                responseData = new String(data, 0, bytes);
                result = result + responseData;
                
                if(tc.isConnected())
                    System.out.println("Info: Connection (" + ipAddress + ") opened successfully...");
            }
        } catch (IOException e) {
        }
        try {
            gpioNumber = gpioNumber.toUpperCase(); //Converts the gpio_number(A to V) to upper case if user entered it as lower case.
            adcNumber = adcNumber.toUpperCase(); //Converts the gpio_number(A to V) to upper case if user entered it as lower case.
            // Buffer to store the response bytes.
            byte[] data = new byte[256];

            //GPIO Set
            data = new byte[256];
            data = (new String("gpio set " + gpioNumber + "\r\n")).getBytes("UTF-8");
            System.out.println("Info: Command sent to GPIO set " + gpioNumber);
            outstr.write(data, 0, data.length);
            outstr.flush();

            //GPIO Clear
            data = new byte[256];
            data = (new String("gpio clear " + gpioNumber + "\r\n")).getBytes("UTF-8");
            System.out.println("Info: Command sent to GPIO clear " + gpioNumber);
            outstr.write(data, 0, data.length);
            outstr.flush();

            //GPIO Read
            data = new byte[256];
            data = (new String("gpio read " + gpioNumber + "\r\n")).getBytes("UTF-8");
            System.out.println("Info: Command sent to GPIO read " + gpioNumber);
            outstr.write(data, 0, data.length);
            outstr.flush();

            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            data = new byte[256];
            int bytes = intstr.read(data, 0, data.length);
            String value = new String(data, 0, bytes);

            if (value.contains("1")) {
                System.out.println("ON");
            } else {
                System.out.println("OFF");
            }

            //ADC Read
            data = new byte[256];
            data = (new String("adc read " + adcNumber + "\r\n")).getBytes("UTF-8");
            System.out.println("Info: Command sent to ADC read " + adcNumber);
            outstr.write(data, 0, data.length);
            outstr.flush();

            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            data = new byte[256];
            bytes = intstr.read(data, 0, data.length);
            String adcValue = new String(data, 0, bytes);
            String result = adcValue;

            if (result != null) {
                result = result.trim();
            }

            Pattern rx = Pattern.compile("\n([0-9]*)");
            Matcher m = rx.matcher(result);

            if (m.find()) {
                result = m.group(0).trim();
            }
            if (result.isEmpty()) {
                rx = (Pattern.compile("\n([0-9]*)"));
                m = rx.matcher(adcValue != null ? adcValue.trim() : "");

                if (m.find()) {
                    result = m.group(0).trim();
                }
            }
            System.out.println(result);
            
            tc.disconnect(); //Telnet connection disconnect
            System.out.println("Info: Connection (" + ipAddress + ") closed successfully...");

        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(EthernetGpioDemo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
